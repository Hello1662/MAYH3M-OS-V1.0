# MAYH3M OS 9.0 — Native 3DS Build

This project is the native C++/libctru port of the uploaded MAYH3M OS 9.0 HTML design.

## What this build does

- Native top/bottom 3DS interface inspired directly by `index.html`.
- Live clock.
- Battery percentage from PTMU.
- Real installed CTR application scan through `AM_GetTitleCount` + `AM_GetTitleList`.
- Reads each installed application's title ID and product code.
- Displays a real game count instead of the HTML test list.
- A launches the selected installed title using `NS_LaunchTitle`.
- SELECT rescans installed titles.
- X opens MAYH3M settings.
- B returns to the library.
- START exits the homebrew.
- D-pad and Circle Pad navigation.
- Touching a game tile launches it.

## Important limitation of this first native port

The HTML preview's test entries contain human-readable names and emoji icons. The public libctru AM API directly exposes installed title IDs, title info, and product codes, but it does not provide a simple `AM_GetTitleName()` call.

Therefore this build deliberately does **not** fake names such as "Mario Kart 7". It reads real installed titles and shows their real product codes/title IDs. The launcher itself is real.

A later metadata layer can parse SMDH/title metadata to display the actual localized game names and icons.

## Build

Your existing devkitARM build should use the same `3ds_rules` setup that already produced your working `.3dsx`.

Because this version uses Citro2D, the environment also needs the 3DS Citro2D development library.

Build:

```bash
make clean
make
```

Output:

```text
MAYH3M-OS.3dsx
```

Copy it to:

```text
/3ds/MAYH3M-OS/MAYH3M-OS.3dsx
```

using your existing FTPD connection.

## Sources

The visual structure is based on the uploaded MAYH3M OS 9.0 HTML.

The installed-title reader uses libctru's AM APIs, and launching uses libctru's NS service.
