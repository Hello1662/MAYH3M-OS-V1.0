#include <3ds.h>
#include <citro2d.h>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <vector>
#include <string>
#include <algorithm>

struct Game {
    u64 titleId;
    FS_MediaType media;
    char productCode[17];
    char label[64];
};

static std::vector<Game> games;
static int selected = 0;
static int scroll = 0;
static int screenMode = 0; // 0 = library, 1 = settings
static C2D_Font font;
static C2D_TextBuf textBuf;
static C2D_Text text;

static C3D_RenderTarget* topTarget;
static C3D_RenderTarget* bottomTarget;

static const u32 C_BG      = C2D_Color32(6, 16, 24, 255);
static const u32 C_PANEL   = C2D_Color32(8, 28, 43, 255);
static const u32 C_PANEL2  = C2D_Color32(15, 52, 72, 255);
static const u32 C_CYAN    = C2D_Color32(126, 234, 255, 255);
static const u32 C_CYAN2   = C2D_Color32(0, 200, 255, 255);
static const u32 C_WHITE   = C2D_Color32(235, 247, 255, 255);
static const u32 C_MUTED   = C2D_Color32(150, 190, 205, 255);
static const u32 C_BLACK   = C2D_Color32(3, 5, 8, 255);
static const u32 C_SELECT  = C2D_Color32(20, 105, 145, 255);

static void drawText(const char* s, float x, float y, float scale, u32 color, bool centered=false) {
    C2D_TextBufClear(textBuf);
    C2D_TextFontParse(&text, font, textBuf, s);
    C2D_TextOptimize(&text);
    if (centered) x = (400.0f - text.width * scale) * 0.5f;
    C2D_DrawText(&text, C2D_WithColor, x, y, 0.5f, scale, scale, color);
}

static void drawTextBottom(const char* s, float x, float y, float scale, u32 color, bool centered=false) {
    C2D_TextBufClear(textBuf);
    C2D_TextFontParse(&text, font, textBuf, s);
    C2D_TextOptimize(&text);
    if (centered) x = (320.0f - text.width * scale) * 0.5f;
    C2D_DrawText(&text, C2D_WithColor, x, y, 0.5f, scale, scale, color);
}

static void scanTitles() {
    games.clear();

    for (int media = MEDIATYPE_SD; media <= MEDIATYPE_GAME_CARD; ++media) {
        u32 count = 0;
        if (R_FAILED(AM_GetTitleCount((FS_MediaType)media, &count)) || count == 0)
            continue;

        std::vector<u64> ids(count);
        u32 read = 0;
        if (R_FAILED(AM_GetTitleList(&read, (FS_MediaType)media, count, ids.data())))
            continue;

        for (u32 i = 0; i < read; ++i) {
            u64 tid = ids[i];
            u32 high = (u32)(tid >> 32);

            // 00040000 = normal CTR applications/games.
            if (high != 0x00040000 && !(media == MEDIATYPE_GAME_CARD && tid != 0))
                continue;

            Game g{};
            g.titleId = tid;
            g.media = (FS_MediaType)media;

            if (tid == 0 && media == MEDIATYPE_GAME_CARD) {
                std::strncpy(g.productCode, "GAMECARD", sizeof(g.productCode)-1);
                std::strncpy(g.label, "GAME CARD", sizeof(g.label)-1);
            } else {
                if (R_FAILED(AM_GetTitleProductCode((FS_MediaType)media, tid, g.productCode))) {
                    std::snprintf(g.productCode, sizeof(g.productCode), "%08lX",
                                  (unsigned long)(tid & 0xffffffff));
                }
                std::snprintf(g.label, sizeof(g.label), "%s", g.productCode);
            }

            games.push_back(g);
        }
    }

    std::sort(games.begin(), games.end(), [](const Game& a, const Game& b) {
        return std::strcmp(a.productCode, b.productCode) < 0;
    });

    if (games.empty()) {
        selected = 0;
        scroll = 0;
    } else {
        if (selected >= (int)games.size()) selected = (int)games.size()-1;
        if (selected < 0) selected = 0;
    }
}

static void launchSelected() {
    if (games.empty()) return;

    Game& g = games[selected];

    u32 pid = 0;
    Result rc = NS_LaunchTitle(g.titleId, 0, &pid);

    // If launch fails, stay in MAYH3M OS and show a diagnostic in the UI.
    if (R_FAILED(rc)) {
        // Product code remains visible; no destructive action is taken.
    }
}

static void drawTop() {
    C2D_TargetClear(topTarget, C_BLACK);
    C2D_SceneBegin(topTarget);

    // Shell
    C2D_DrawRectSolid(0, 0, 0.9f, 400, 240, C_BLACK);
    C2D_DrawRectSolid(8, 8, 0.8f, 384, 224, C_PANEL);

    // Status bar
    C2D_DrawRectSolid(8, 8, 0.7f, 384, 27, C_BLACK);
    drawText("ELECTRIC MAYH3M", 17, 12, 0.42f, C_CYAN);

    char clockText[32];
    time_t now = time(nullptr);
    struct tm* lt = localtime(&now);
    if (lt)
        std::snprintf(clockText, sizeof(clockText), "%02d:%02d",
                      lt->tm_hour, lt->tm_min);
    else
        std::strcpy(clockText, "--:--");

    u8 bat = 0;
    PTMU_GetBatteryLevel(&bat);
    int pct = std::min(100, (int)bat * 20);

    char status[64];
    std::snprintf(status, sizeof(status), "%s   BAT %d%%", clockText, pct);
    drawText(status, 245, 13, 0.35f, C_WHITE);

    // Main title
    drawText("MAYH3M OS", 0, 73, 1.18f, C_WHITE, true);
    drawText("NEW NINTENDO 3DS XL EDITION", 0, 115, 0.43f, C_CYAN, true);

    // Glow-like lines
    C2D_DrawRectSolid(65, 151, 0.7f, 270, 2, C_CYAN2);
    C2D_DrawRectSolid(105, 156, 0.7f, 190, 1, C_CYAN);

    drawText("FULL NATIVE 3DS MODE", 0, 183, 0.38f, C_MUTED, true);
}

static void drawCircle(float x, float y, float r, u32 c) {
    C2D_DrawCircleSolid(x, y, 0.7f, r, c);
    C2D_DrawCircleSolid(x, y, 0.6f, r - 5, C_BLACK);
    C2D_DrawCircleSolid(x, y, 0.5f, r - 9, c);
}

static void drawDpad() {
    float cx = 42, cy = 154;
    C2D_DrawRectSolid(cx-9, cy-32, 0.7f, 18, 64, C_PANEL2);
    C2D_DrawRectSolid(cx-32, cy-9, 0.7f, 64, 18, C_PANEL2);
}

static void drawABXY() {
    float cx = 278, cy = 155;
    drawCircle(cx+25, cy, 16, C_PANEL2); drawTextBottom("A", cx+20, cy-7, 0.38f, C_WHITE);
    drawCircle(cx-25, cy, 16, C_PANEL2); drawTextBottom("Y", cx-30, cy-7, 0.38f, C_WHITE);
    drawCircle(cx, cy-25, 16, C_PANEL2); drawTextBottom("X", cx-5, cy-32, 0.38f, C_WHITE);
    drawCircle(cx, cy+25, 16, C_PANEL2); drawTextBottom("B", cx-5, cy+18, 0.38f, C_WHITE);
}

static void drawLibrary() {
    C2D_DrawRectSolid(0, 0, 0.9f, 320, 240, C_BG);

    // Header
    C2D_DrawRectSolid(7, 7, 0.8f, 306, 30, C_BLACK);
    drawTextBottom("GAME LIBRARY", 16, 12, 0.48f, C_CYAN);

    char count[32];
    std::snprintf(count, sizeof(count), "%d GAMES", (int)games.size());
    drawTextBottom(count, 240, 13, 0.35f, C_MUTED);

    // Game grid, matching the HTML's 4-column concept.
    const int cols = 4;
    const float x0 = 67.0f;
    const float y0 = 49.0f;
    const float w = 57.0f;
    const float h = 47.0f;
    const float gap = 5.0f;

    int rows = (int)((games.size() + cols - 1) / cols);
    int maxRowsVisible = 3;
    int maxScroll = std::max(0, rows - maxRowsVisible);
    if (scroll > maxScroll) scroll = maxScroll;

    for (int slot = 0; slot < cols * maxRowsVisible; ++slot) {
        int idx = scroll * cols + slot;
        int col = slot % cols;
        int row = slot / cols;
        float x = x0 + col * (w + gap);
        float y = y0 + row * (h + gap);

        if (idx >= (int)games.size()) {
            C2D_DrawRectSolid(x, y, 0.7f, w, h, C_PANEL);
            continue;
        }

        bool active = idx == selected;
        C2D_DrawRectSolid(x, y, 0.7f, w, h, active ? C_SELECT : C_PANEL2);
        C2D_DrawRectSolid(x+2, y+2, 0.6f, w-4, 16, active ? C_CYAN2 : C_BG);

        drawTextBottom("3DS", x+17, y+4, 0.30f, C_WHITE);
        drawTextBottom(games[idx].productCode, x+4, y+22, 0.25f, C_WHITE);

        char tid[24];
        std::snprintf(tid, sizeof(tid), "%08lX", (unsigned long)(games[idx].titleId & 0xffffffff));
        drawTextBottom(tid, x+4, y+35, 0.20f, C_MUTED);
    }

    // Footer
    C2D_DrawRectSolid(7, 208, 0.8f, 306, 25, C_BLACK);
    drawTextBottom("D-PAD SELECT", 13, 214, 0.27f, C_MUTED);
    drawTextBottom("A LAUNCH", 110, 214, 0.27f, C_CYAN);
    drawTextBottom("START EXIT", 204, 214, 0.27f, C_MUTED);
    drawTextBottom("MAYH3M OS 9.0", 0, 226, 0.22f, C_MUTED, true);

    // Hardware controls around the screen
    drawCircle(42, 52, 23, C_PANEL2);
    drawDpad();
    drawCircle(278, 52, 13, C_PANEL2);
    drawABXY();

    C2D_DrawRectSolid(111, 219, 0.6f, 45, 10, C_PANEL2);
    C2D_DrawRectSolid(164, 219, 0.6f, 45, 10, C_PANEL2);
    drawTextBottom("SELECT", 116, 220, 0.20f, C_MUTED);
    drawTextBottom("START", 171, 220, 0.20f, C_MUTED);
}

static void drawSettings() {
    C2D_DrawRectSolid(0, 0, 0.9f, 320, 240, C_BG);
    drawTextBottom("MAYH3M SETTINGS", 0, 16, 0.62f, C_CYAN, true);

    drawTextBottom("TITLE READER", 20, 55, 0.42f, C_WHITE);
    drawTextBottom("Reads installed CTR application titles", 20, 75, 0.30f, C_MUTED);

    drawTextBottom("GAME COUNT", 20, 105, 0.42f, C_WHITE);
    char count[32];
    std::snprintf(count, sizeof(count), "%d", (int)games.size());
    drawTextBottom(count, 250, 105, 0.42f, C_CYAN);

    drawTextBottom("A  RESCAN TITLES", 20, 145, 0.34f, C_CYAN);
    drawTextBottom("B  BACK TO LIBRARY", 20, 172, 0.34f, C_CYAN);
    drawTextBottom("START  EXIT", 20, 199, 0.34f, C_MUTED);
}

int main(int argc, char** argv) {
    gfxInitDefault();
    hidInit();
    ptmuInit();
    amInit();
    nsInit();

    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Prepare();

    font = C2D_FontLoadSystem(CFG_REGION_USA);
    textBuf = C2D_TextBufNew(16384);

    topTarget = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    bottomTarget = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);

    scanTitles();

    while (aptMainLoop()) {
        hidScanInput();
        u32 down = hidKeysDown();
        u32 held = hidKeysHeld();

        if (down & KEY_START) break;

        if (screenMode == 0) {
            if (down & KEY_LEFT)  selected--;
            if (down & KEY_RIGHT) selected++;
            if (down & KEY_UP)    selected -= 4;
            if (down & KEY_DOWN)  selected += 4;

            if (selected < 0) selected = 0;
            if (!games.empty() && selected >= (int)games.size())
                selected = (int)games.size()-1;

            if (down & KEY_A) launchSelected();
            if (down & KEY_SELECT) scanTitles();

            if (down & KEY_X) screenMode = 1;

            if (held & KEY_CPAD_UP)   selected = std::max(0, selected - 4);
            if (held & KEY_CPAD_DOWN) selected = std::min((int)games.size()-1, selected + 4);

            if (!games.empty()) {
                int row = selected / 4;
                if (row < scroll) scroll = row;
                if (row >= scroll + 3) scroll = row - 2;
            }
        } else {
            if (down & KEY_A) scanTitles();
            if (down & KEY_B) screenMode = 0;
        }

        touchPosition touch;
        hidTouchRead(&touch);
        if (down & KEY_TOUCH) {
            if (screenMode == 0) {
                const float x0 = 67.0f, y0 = 49.0f, w = 57.0f, h = 47.0f, gap = 5.0f;
                for (int slot = 0; slot < 12; ++slot) {
                    int idx = scroll * 4 + slot;
                    if (idx >= (int)games.size()) continue;
                    int col = slot % 4, row = slot / 4;
                    float x = x0 + col * (w + gap);
                    float y = y0 + row * (h + gap);
                    if (touch.px >= x && touch.px < x+w &&
                        touch.py >= y && touch.py < y+h) {
                        selected = idx;
                        launchSelected();
                        break;
                    }
                }
            }
        }

        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        drawTop();

        C2D_TargetClear(bottomTarget, C_BG);
        C2D_SceneBegin(bottomTarget);
        if (screenMode == 0) drawLibrary();
        else drawSettings();

        C3D_FrameEnd(0);
    }

    textBuf = nullptr;
    C2D_Fini();
    C3D_Fini();
    nsExit();
    amExit();
    ptmuExit();
    hidExit();
    gfxExit();
    return 0;
}
